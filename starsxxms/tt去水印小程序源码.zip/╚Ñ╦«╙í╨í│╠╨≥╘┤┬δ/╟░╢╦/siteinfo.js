var siteinfo = { "uniacid": "2", "acid": "2", "multiid": "0", "version": "2.0", "siteroot": "https://www.pnp8.com/app/index.php", "design_method": "3" }
module.exports = siteinfo