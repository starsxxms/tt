Page({
    data: {},
    onShareAppMessage: function() {}
});